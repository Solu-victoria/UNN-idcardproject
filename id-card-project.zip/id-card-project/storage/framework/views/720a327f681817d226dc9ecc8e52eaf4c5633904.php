<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../idCard.css">
    <title>ID Card</title>
<!--     
    So lets start -->
</head>


<body>
        <div class="container">
            <?php if($details->isEmpty()): ?> 
                <b>Id card not applied for yet... </b> <br>
                <a href="<?php echo e(route('id-request')); ?>">Click here to apply</a>

            <?php else: ?>
                <div class="padding">
                    <div class="font">
                        <div class="top">
                            <img src="../../images/<?php echo e(Auth::user()->image); ?>">
                        </div>
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bottom">
                            <p><?php echo e(Auth::user()->name); ?></p>
                            <?php $Stype = 'student-type'; 
                                $id_no = urlencode(urlencode(Auth::user()->ident_number));
                            ?>
                            <p class="desi"><?php echo e($detail->$Stype); ?></p>
                            <div class="barcode">
                              <?php echo QrCode::size(80)->generate( URL('userinfo/'.$id_no)); ?>

                            </div>
                            
                            <br>
                            <p class="no"><?php echo e(Auth::user()->ident_number); ?></p>
                            <p class="no"><?php echo e(Auth::user()->department); ?></p>
                        </div>
                    </div>
                </div>
                <div class="back">
                    <h1 class="Details">Information</h1>
                    <hr class="hr">
                    <div class="details-info">
                        <p><b>University of Nigeria Nsukka </b></p>
                        <p><?php echo e(Auth::user()->faculty); ?></p>
                        <p><b>Mobile No:</b></p>
                        <?php $phone = 'phone-no'; ?>
                        <p><?php echo e(Auth::user()->$phone); ?></p>
                        <p><b>Residence Address:</b></p>
                        <p><?php echo e($detail->address); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <h6> if found return to ID card office, UNN</h6>
                        </div>
                        <div class="logo">
                            <img src="../barcode.PNG">
                        </div>
                        <hr>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <a href="../index">Back to portal</a>
</body>
        
</html><?php /**PATH C:\xampp\htdocs\Web_dev_work2\id\id-card-project\resources\views/portal/id.blade.php ENDPATH**/ ?>