
<?php echo $__env->make("headercon", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
       
    </div>
	<ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="/">Home</a>
        </li>
        <li class="breadcrumb-item active">About</li>
    </ol>
	 <!-- //banner-text -->
	 <section class="banner_bottom1 py-md-5">
		<div class="container py-4 mt-2">
			<h3 class="heading-agileinfo text-center">About  <span>Us</span></h3>
			<div class="inner_sec_info_wthree_agile mt-md-5 pt-3">
				<div class="row help_full">
					<div class="col-lg-6 banner_bottom_grid help">
						<img src="images/g1.jpg" alt=" " class="img-fluid">
					</div>
					<div class="col-lg-6 banner_bottom_left1">
						<h4>Welcome to UNN ID card </h4>
						<p>Not having the proper photo ID can prevent you from doing many things. Think about your own security. You wouldn’t want someone using your personal credit score to open accounts or use your bank card to make purchases. Your photo identification protects you.</p>
						<P>	An identity document (also called a piece of identification or ID, or colloquially as papers) is any document that may be used to prove a person's identity. If issued in a small, standard credit card size form, it is usually called an identity card (IC, ID card, citizen card), or passport card.</p>
						</div>
				</div>
			</div>
		</div>
	</section>

	
<?php echo $__env->make("footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH C:\xampp\htdocs\Web_dev_work2\id\id-card-project\resources\views/about.blade.php ENDPATH**/ ?>