<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="icon" href="images/favicon-32x32.png">
    <title><?php echo e($info->name); ?>'s details</title>
    <link rel="stylesheet" href="../css/u-info.css" type='text/css' media="all">
</head>
<body>
<div class="container">

<div class="logo">
    <img src="../images/favicon-32x32.png" height="5%" width="5%" alt="">
    University of Nigeria Nsukka
</div>


<div class="marquee">
    Certificate of Verificaiton
</div>

<div class="marquee">
    <img src="../images/<?php echo e($info->image); ?>" height="20%" width="20%" alt="">
</div>

<div class="assignment">
    This certificate is to prove that
</div>

<div class="person">
<?php echo e($info->name); ?>

</div>

<div class="reason">
    is a student of UNN from <?php echo e($info->department); ?><br/>
    with id <?php echo e($info->ident_number); ?>

</div>
</div>
</body>
</html>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\Web_dev_work2\id\id-card-project\resources\views/userinfo.blade.php ENDPATH**/ ?>